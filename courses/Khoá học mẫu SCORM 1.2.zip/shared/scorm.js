function findAPI(w){for(let i=0;i<10&&w;i++){if(w.API)return w.API;if(w.parent===w)break;w=w.parent;}return null;}
var api=findAPI(window);
window.addEventListener('load',()=>{document.getElementById('st').textContent=api?('API: '+api.LMSInitialize('')+' | entry='+api.LMSGetValue('cmi.core.entry')+' | name='+api.LMSGetValue('cmi.core.student_name')):'Không tìm thấy API';});
window.addEventListener('unload',()=>{if(api){api.LMSSetValue('cmi.core.session_time','0000:01:30.00');api.LMSFinish('');}});
